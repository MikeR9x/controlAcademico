package com.example.controlacademico.models

data class Grade(

    var materiaId: String = "",
    var alumnoId: String = "",
    var parcial1: Double = 0.0,
    var parcial2: Double = 0.0,
    var final: Double = 0.0

)