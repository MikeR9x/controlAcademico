package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.firestore.FirebaseFirestore

class ManageUsersActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    private val usuarios = mutableListOf<String>()
    private val userIds = mutableListOf<String>()
    private val roles = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_users)

        val spinner = findViewById<Spinner>(R.id.userSpinner)
        val roleSpinner = findViewById<Spinner>(R.id.roleSpinner)
        val changeBtn = findViewById<Button>(R.id.changeRoleBtn)

        cargarUsuarios(spinner)

        val roleAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listOf("alumno", "profesor")
        )

        roleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        roleSpinner.adapter = roleAdapter

        changeBtn.setOnClickListener {

            val userIndex = spinner.selectedItemPosition
            val newRole = roleSpinner.selectedItem.toString()
            val userId = userIds[userIndex]

            db.collection("users")
                .document(userId)
                .update("role", newRole)
                .addOnSuccessListener {

                    Toast.makeText(this, "Rol actualizado", Toast.LENGTH_SHORT).show()
                    cargarUsuarios(spinner)
                }
        }
    }

    private fun cargarUsuarios(spinner: Spinner) {

        db.collection("users")
            .get()
            .addOnSuccessListener { result ->

                usuarios.clear()
                userIds.clear()
                roles.clear()

                for (doc in result) {

                    val name = doc.getString("name") ?: "Sin nombre"
                    val email = doc.getString("email") ?: ""
                    val role = doc.getString("role") ?: "sin rol"

                    usuarios.add("$name ($email) - $role")
                    userIds.add(doc.id)
                    roles.add(role)
                }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    usuarios
                )

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                spinner.adapter = adapter
            }
    }
}