package com.example.controlacademico.models

data class User(

    var uid: String = "",
    var studentId: String = "",
    var name: String = "",
    var email: String = "",
    var role: String = "",
    var materias: List<String> = listOf()

)