package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class AddGradeActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val materias = mutableListOf<String>()
    private val materiasId = mutableListOf<String>()
    private val alumnos = mutableListOf<String>()
    private val alumnosId = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_grade)

        val materiaSpinner = findViewById<Spinner>(R.id.materiaSpinner)
        val alumnoSpinner = findViewById<Spinner>(R.id.alumnoSpinner)
        val p1 = findViewById<EditText>(R.id.parcial1)
        val p2 = findViewById<EditText>(R.id.parcial2)
        val finalGrade = findViewById<EditText>(R.id.finalGrade)
        val saveBtn = findViewById<Button>(R.id.saveGradeBtn)

        cargarMaterias(materiaSpinner)
        cargarAlumnos(alumnoSpinner)

        saveBtn.setOnClickListener {

            val materiaIndex = materiaSpinner.selectedItemPosition
            val alumnoIndex = alumnoSpinner.selectedItemPosition

            if (materiaIndex < 0 || alumnoIndex < 0) {
                Toast.makeText(this, "Seleccione materia y alumno", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val materiaId = materiasId[materiaIndex]
            val alumnoId = alumnosId[alumnoIndex]

            val calificaciones = hashMapOf<String, Any>(
                "parcial1" to (p1.text.toString().toDoubleOrNull() ?: 0.0),
                "parcial2" to (p2.text.toString().toDoubleOrNull() ?: 0.0),
                "final" to (finalGrade.text.toString().toDoubleOrNull() ?: 0.0)
            )


            val gradeRecord = hashMapOf<String, Any>(
                "materiaId" to materiaId,
                "alumnoId" to alumnoId
            ) + calificaciones


            db.collection("grades")
                .add(gradeRecord)


            db.collection("users")
                .whereEqualTo("studentId", alumnoId)
                .get()
                .addOnSuccessListener { result ->
                    for (doc in result) {
                        val userRef = db.collection("users").document(doc.id)

                        val updates = hashMapOf<String, Any>(
                            "grades.$materiaId" to calificaciones
                        )

                        userRef.update(updates)
                    }

                    Toast.makeText(this, "Calificación guardada correctamente", Toast.LENGTH_SHORT).show()
                    finish()
                }
        }
    }

    private fun cargarMaterias(spinner: Spinner) {
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->
            val studentId = userDoc.getString("studentId") ?: return@addOnSuccessListener
            db.collection("materias")
                .whereEqualTo("profesorId", studentId)
                .get()
                .addOnSuccessListener { result ->
                    materias.clear()
                    materiasId.clear()
                    for (doc in result) {
                        val nombre = doc.getString("nombre") ?: "Sin nombre"
                        val id = doc.getString("materiaId") ?: ""
                        materias.add("$nombre ($id)")
                        materiasId.add(id)
                    }
                    val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, materias)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner.adapter = adapter
                }
        }
    }

    private fun cargarAlumnos(spinner: Spinner) {
        db.collection("users")
            .whereEqualTo("role", "alumno")
            .get()
            .addOnSuccessListener { result ->
                alumnos.clear()
                alumnosId.clear()
                for (doc in result) {
                    val nombre = doc.getString("name") ?: "Sin nombre"
                    val id = doc.getString("studentId") ?: ""
                    alumnos.add("$nombre ($id)")
                    alumnosId.add(id)
                }
                val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, alumnos)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
            }
    }
}
