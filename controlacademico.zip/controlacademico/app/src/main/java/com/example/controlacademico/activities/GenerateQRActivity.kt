package com.example.controlacademico.activities

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject

class GenerateQRActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generate_qractivity)

        val qrImage = findViewById<ImageView>(R.id.qrImage)

        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        val timestamp = System.currentTimeMillis()

        val qrData = JSONObject()
        qrData.put("uid", uid)
        qrData.put("timestamp", timestamp)

        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(
            qrData.toString(),
            BarcodeFormat.QR_CODE,
            600,
            600
        )

        val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565)

        for (x in 0 until 600) {
            for (y in 0 until 600) {

                bitmap.setPixel(
                    x,
                    y,
                    if (bitMatrix[x, y]) android.graphics.Color.BLACK
                    else android.graphics.Color.WHITE
                )
            }
        }

        qrImage.setImageBitmap(bitmap)
    }
}