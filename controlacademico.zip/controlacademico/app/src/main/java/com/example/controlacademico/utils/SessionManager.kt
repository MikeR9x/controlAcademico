package com.example.controlacademico.utils

import android.content.Context

class SessionManager(context: Context) {

    private val prefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE)

    fun saveSession(uid: String, role: String) {
        prefs.edit()
            .putString("uid", uid)
            .putString("role", role)
            .apply()
    }

    fun getRole(): String? {
        return prefs.getString("role", null)
    }

    fun isLoggedIn(): Boolean {
        return prefs.contains("uid")
    }

    fun logout() {
        prefs.edit().clear().apply()
    }
}