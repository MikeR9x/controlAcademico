package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfesorMateriasActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profesor_materias)

        val text = findViewById<TextView>(R.id.materiasText)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->

            val studentId = userDoc.getString("studentId") ?: return@addOnSuccessListener

            val calendario = mutableMapOf(
                "Lunes" to mutableListOf<String>(),
                "Martes" to mutableListOf<String>(),
                "Miércoles" to mutableListOf<String>(),
                "Jueves" to mutableListOf<String>(),
                "Viernes" to mutableListOf<String>()
            )

            db.collection("materias")
                .whereEqualTo("profesorId", studentId)
                .get()
                .addOnSuccessListener { result ->

                    if (result.isEmpty) {
                        text.text = "No tienes materias asignadas."
                        return@addOnSuccessListener
                    }

                    for (doc in result) {

                        val nombre = doc.getString("nombre") ?: "Sin nombre"
                        val materiaId = doc.getString("materiaId") ?: "Sin ID"
                        val horario = doc.getString("horario") ?: "Sin horario"
                        val dias = doc.getString("dias") ?: ""

                        val alumnos = doc.get("alumnos") as? List<String> ?: listOf()

                        val textoMateria = """
                            📘 $nombre
                            ID: $materiaId
                            ⏰ $horario
                            👥 Alumnos: ${alumnos.size}
                        """.trimIndent()

                        val listaDias = dias.split(" y ")

                        for (dia in listaDias) {
                            val limpio = dia.trim()
                            if (calendario.containsKey(limpio)) {
                                calendario[limpio]?.add(textoMateria)
                            }
                        }
                    }

                    val builder = StringBuilder()

                    for ((dia, lista) in calendario) {

                        builder.append("📅 $dia\n")

                        if (lista.isEmpty()) {
                            builder.append("  (Sin materias)\n")
                        } else {
                            for (materia in lista) {
                                builder.append("  $materia\n\n")
                            }
                        }

                        builder.append("\n")
                    }

                    text.text = builder.toString()
                }
        }.addOnFailureListener {
            Toast.makeText(this, "Error al cargar materias", Toast.LENGTH_SHORT).show()
        }
    }
}