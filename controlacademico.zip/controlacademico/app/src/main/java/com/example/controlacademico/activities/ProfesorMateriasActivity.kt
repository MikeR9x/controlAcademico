package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfesorMateriasActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profesor_materias)

        val text = findViewById<TextView>(R.id.materiasText)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { userDoc ->

                val studentId = userDoc.getString("studentId")
                if (studentId.isNullOrEmpty()) {
                    Toast.makeText(this, "No se encontró studentId", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                db.collection("materias")
                    .whereEqualTo("profesorId", studentId)
                    .get()
                    .addOnSuccessListener { result ->

                        if (result.isEmpty) {
                            text.text = "No tienes materias asignadas."
                            return@addOnSuccessListener
                        }

                        val materiasText = StringBuilder()

                        for (doc in result) {

                            val nombre = doc.getString("nombre") ?: "Sin nombre"
                            val materiaId = doc.getString("materiaId") ?: "Sin ID"
                            val horario = doc.getString("horario") ?: "Sin horario"
                            val alumnos = doc.get("alumnos") as? List<String> ?: listOf()

                            materiasText.append("Materia: $nombre\n")
                            materiasText.append("ID: $materiaId\n")
                            materiasText.append("Horario: $horario\n")
                            materiasText.append("Alumnos inscritos: ${alumnos.size}\n")
                            materiasText.append("-------------------------\n")
                        }

                        text.text = materiasText.toString()
                    }
            }
    }
}