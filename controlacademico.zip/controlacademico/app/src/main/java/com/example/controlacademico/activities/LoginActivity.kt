package com.example.controlacademico.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.example.controlacademico.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        session = SessionManager(this)

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val loginBtn = findViewById<Button>(R.id.loginBtn)
        val registerBtn = findViewById<Button>(R.id.registerBtn)

        val sessionManager = SessionManager(this)

        if (sessionManager.isLoggedIn()) {
            val role = sessionManager.getRole()

            // Redirigir según rol
            when (role) {
                "admin" -> startActivity(Intent(this, AdminActivity::class.java))
                "profesor" -> startActivity(Intent(this, ProfesorActivity::class.java))
                "alumno" -> startActivity(Intent(this, AlumnoActivity::class.java))
            }
            finish()
        }

        loginBtn.setOnClickListener {

            auth.signInWithEmailAndPassword(
                email.text.toString(),
                password.text.toString()
            ).addOnSuccessListener {

                val uid = auth.currentUser!!.uid

                db.collection("users")
                    .document(uid)
                    .get()
                    .addOnSuccessListener { document ->

                        val role = document.getString("role")!!

                        session.saveSession(uid, role)

                        when (role) {

                            "admin" -> startActivity(
                                Intent(this, AdminActivity::class.java)
                            )

                            "profesor" -> startActivity(
                                Intent(this, ProfesorActivity::class.java)
                            )

                            "alumno" -> startActivity(
                                Intent(this, AlumnoActivity::class.java)
                            )
                        }

                        finish()
                    }
            }
                .addOnFailureListener {
                    Toast.makeText(this, "Login incorrecto", Toast.LENGTH_SHORT).show()
                }
        }

        registerBtn.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}
