package com.example.controlacademico.models

data class Materia(

    var materiaId: String = "",
    var nombre: String = "",
    var profesorId: String = "",
    var profesorNombre: String = "",
    var horario: String = "",
    var alumnos: List<String> = listOf()

)
