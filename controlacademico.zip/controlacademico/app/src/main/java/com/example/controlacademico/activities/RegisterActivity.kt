package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val name = findViewById<EditText>(R.id.name)
        val studentId = findViewById<EditText>(R.id.studentId)
        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val registerBtn = findViewById<Button>(R.id.registerBtn)

        registerBtn.setOnClickListener {

            auth.createUserWithEmailAndPassword(
                email.text.toString(),
                password.text.toString()
            ).addOnSuccessListener {

                val uid = auth.currentUser!!.uid

                val user = hashMapOf(

                    "uid" to uid,
                    "studentId" to studentId.text.toString(),
                    "name" to name.text.toString(),
                    "email" to email.text.toString(),
                    "role" to "alumno",
                    "materias" to listOf<String>()
                )

                db.collection("users")
                    .document(uid)
                    .set(user)
                    .addOnSuccessListener {

                        Toast.makeText(this, "Usuario registrado", Toast.LENGTH_SHORT).show()
                        finish()

                    }
            }
        }
    }
}