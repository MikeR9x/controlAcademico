package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class CreateMateriaActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    private val profesores = ArrayList<String>()
    private val profesoresId = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_materia)

        val materiaId = findViewById<EditText>(R.id.materiaId)
        val nombre = findViewById<EditText>(R.id.nombreMateria)
        val horario = findViewById<EditText>(R.id.horarioMateria)
        val profesorSpinner = findViewById<Spinner>(R.id.profesorSpinner)
        val diasSpinner = findViewById<Spinner>(R.id.diasSpinner)
        val createBtn = findViewById<Button>(R.id.createMateriaBtn)

        // 🔹 Cargar profesores
        cargarProfesores(profesorSpinner)

        // 🔹 Configurar Spinner de días
        val diasOpciones = listOf(
            "Lunes y Miércoles",
            "Martes y Jueves",
            "Viernes"
        )

        val diasAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            diasOpciones
        )

        diasAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        diasSpinner.adapter = diasAdapter

        // 🔹 Botón crear materia
        createBtn.setOnClickListener {

            val idMateria = materiaId.text.toString().trim()
            val nombreMateria = nombre.text.toString().trim()
            val horarioMateria = horario.text.toString().trim()
            val diasSeleccionados = diasSpinner.selectedItem.toString()

            if (idMateria.isEmpty() || nombreMateria.isEmpty() || horarioMateria.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val index = profesorSpinner.selectedItemPosition

            if (index < 0) {
                Toast.makeText(this, "Selecciona un profesor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val profesorId = profesoresId[index]
            val profesorNombre = profesores[index]

            val materia = hashMapOf(

                "materiaId" to idMateria,
                "nombre" to nombreMateria,
                "profesorId" to profesorId,
                "profesorNombre" to profesorNombre,
                "horario" to horarioMateria,
                "dias" to diasSeleccionados,
                "alumnos" to listOf<String>()
            )

            // 1️⃣ Crear materia en Firestore
            db.collection("materias")
                .document(idMateria)
                .set(materia)
                .addOnSuccessListener {

                    // 2️⃣ Asignar materia al profesor
                    db.collection("users")
                        .whereEqualTo("studentId", profesorId)
                        .get()
                        .addOnSuccessListener { result ->

                            for (doc in result) {

                                db.collection("users")
                                    .document(doc.id)
                                    .update(
                                        "materias",
                                        FieldValue.arrayUnion(idMateria)
                                    )
                            }

                            Toast.makeText(
                                this,
                                "Materia creada correctamente",
                                Toast.LENGTH_SHORT
                            ).show()

                            finish()
                        }
                }
                .addOnFailureListener {

                    Toast.makeText(this, "Error al crear materia", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun cargarProfesores(spinner: Spinner) {

        db.collection("users")
            .whereEqualTo("role", "profesor")
            .get()
            .addOnSuccessListener { result ->

                profesores.clear()
                profesoresId.clear()

                for (doc in result) {

                    val name = doc.getString("name") ?: "Sin nombre"
                    val id = doc.getString("studentId") ?: ""

                    profesores.add(name)
                    profesoresId.add(id)
                }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    profesores
                )

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
            }
    }
}
