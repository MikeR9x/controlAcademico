package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.firestore.FirebaseFirestore

class CreateMateriaActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val profesores = ArrayList<String>()
    private val profesoresId = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_materia)

        val materiaId = findViewById<EditText>(R.id.materiaId)
        val nombre = findViewById<EditText>(R.id.nombreMateria)
        val horario = findViewById<EditText>(R.id.horarioMateria)
        val profesorSpinner = findViewById<Spinner>(R.id.profesorSpinner)
        val createBtn = findViewById<Button>(R.id.createMateriaBtn)

        cargarProfesores(profesorSpinner)

        createBtn.setOnClickListener {

            val idMateria = materiaId.text.toString()
            val nombreMateria = nombre.text.toString()
            val horarioMateria = horario.text.toString()

            val index = profesorSpinner.selectedItemPosition
            val profesorId = profesoresId[index]
            val profesorNombre = profesores[index]

            val materia = hashMapOf(

                "materiaId" to idMateria,
                "nombre" to nombreMateria,
                "profesorId" to profesorId,
                "profesorNombre" to profesorNombre,
                "horario" to horarioMateria,
                "alumnos" to listOf<String>()
            )

            // 1️⃣ Crear materia
            db.collection("materias")
                .document(idMateria)
                .set(materia)
                .addOnSuccessListener {

                    // 2️⃣ Actualizar profesor agregando la materia
                    db.collection("users")
                        .whereEqualTo("studentId", profesorId)
                        .get()
                        .addOnSuccessListener { result ->

                            for (doc in result) {

                                db.collection("users")
                                    .document(doc.id)
                                    .update(
                                        "materias",
                                        com.google.firebase.firestore.FieldValue.arrayUnion(idMateria)
                                    )
                            }

                            Toast.makeText(this, "Materia creada y asignada al profesor", Toast.LENGTH_SHORT).show()
                            finish()
                        }
                }
        }
    }

    private fun cargarProfesores(spinner: Spinner) {

        db.collection("users")
            .whereEqualTo("role", "profesor")
            .get()
            .addOnSuccessListener { result ->

                for (doc in result) {

                    val name = doc.getString("name")!!
                    val id = doc.getString("studentId")!!

                    profesores.add(name)
                    profesoresId.add(id)
                }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    profesores
                )

                spinner.adapter = adapter
            }
    }
}