package com.example.controlacademico.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.example.controlacademico.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth

class ProfesorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profesor)

        val scanBtn = findViewById<Button>(R.id.scanBtn)
        val addGradesBtn = findViewById<Button>(R.id.addGradesBtn)
        val viewMateriasBtn = findViewById<Button>(R.id.viewMateriasBtn)
        val logoutBtn = findViewById<Button>(R.id.logoutBtn)

        scanBtn.setOnClickListener {

            startActivity(
                Intent(this, ScanQRActivity::class.java)
            )
        }

        addGradesBtn.setOnClickListener {

            val intent = Intent(this, AddGradeActivity::class.java)
            startActivity(intent)

        }
        viewMateriasBtn.setOnClickListener {

            val intent = Intent(this, ProfesorMateriasActivity::class.java)
            startActivity(intent)

        }


        logoutBtn.setOnClickListener {
            val sessionManager = SessionManager(this)
            sessionManager.logout()
            FirebaseAuth.getInstance().signOut()  // Cierra sesión también en Firebase
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}