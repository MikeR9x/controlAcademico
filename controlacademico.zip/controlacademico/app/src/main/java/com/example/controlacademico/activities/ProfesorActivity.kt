package com.example.controlacademico.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R

class ProfesorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profesor)

        val scanBtn = findViewById<Button>(R.id.scanBtn)
        val addGradesBtn = findViewById<Button>(R.id.addGradesBtn)
        val viewMateriasBtn = findViewById<Button>(R.id.viewMateriasBtn)

        scanBtn.setOnClickListener {

            startActivity(
                Intent(this, ScanQRActivity::class.java)
            )
        }

        addGradesBtn.setOnClickListener {

            val intent = Intent(this, AddGradeActivity::class.java)
            startActivity(intent)

        }
        viewMateriasBtn.setOnClickListener {

            val intent = Intent(this, ProfesorMateriasActivity::class.java)
            startActivity(intent)

        }
    }
}