package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.zxing.integration.android.IntentIntegrator
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class ScanQRActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startScanner()
    }

    private fun startScanner() {

        val integrator = IntentIntegrator(this)

        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
        integrator.setPrompt("Escanea el QR del alumno")
        integrator.setBeepEnabled(true)
        integrator.initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {

        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)

        if (result != null) {

            if (result.contents != null) {

                processQR(result.contents)

            } else {

                Toast.makeText(this, "Escaneo cancelado", Toast.LENGTH_SHORT).show()
                finish()
            }

        } else {

            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun processQR(qrContent: String) {

        val json = JSONObject(qrContent)

        val uid = json.getString("uid")
        val timestamp = json.getLong("timestamp")

        val currentTime = System.currentTimeMillis()

        if (currentTime - timestamp > 120000) {

            Toast.makeText(this, "QR expirado", Toast.LENGTH_SHORT).show()
            return
        }

        mostrarDatosAlumno(uid)
    }

    private fun mostrarDatosAlumno(uid: String) {

        db.collection("users")
            .document(uid)
            .get()
            .addOnSuccessListener { doc ->

                val name = doc.getString("name") ?: "Sin nombre"
                val studentId = doc.getString("studentId") ?: "Sin ID"

                val date = System.currentTimeMillis()
                val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                val formattedDate = sdf.format(Date(date))

                val message = """
                    
                    Alumno: $name
                    
                    ID: $studentId
                    
                    Fecha: $formattedDate
                    
                """.trimIndent()

                AlertDialog.Builder(this)
                    .setTitle("Asistencia Detectada")
                    .setMessage(message)
                    .setPositiveButton("Confirmar") { _, _ ->

                        saveAttendance(studentId, name, date)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
    }

    private fun saveAttendance(studentId: String, name: String, date: Long) {

        val attendance = hashMapOf(

            "studentId" to studentId,
            "name" to name,
            "date" to date
        )

        db.collection("attendance")
            .add(attendance)
            .addOnSuccessListener {

                Toast.makeText(this, "Asistencia registrada", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {

                Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show()
            }
    }
}