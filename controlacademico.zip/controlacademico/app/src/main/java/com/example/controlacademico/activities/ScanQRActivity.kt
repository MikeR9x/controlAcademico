package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.zxing.integration.android.IntentIntegrator
import com.example.controlacademico.R
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class ScanQRActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    private val materias = mutableListOf<String>()
    private val materiasId = mutableListOf<String>()

    private var selectedMateriaId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan_qractivity)

        val spinner = findViewById<Spinner>(R.id.materiaSpinner)
        val scanBtn = findViewById<Button>(R.id.startScanBtn)

        cargarMaterias(spinner)

        scanBtn.setOnClickListener {

            val index = spinner.selectedItemPosition

            if (index < 0) {
                Toast.makeText(this, "Selecciona una materia", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            selectedMateriaId = materiasId[index]

            startScanner()
        }
    }

    private fun cargarMaterias(spinner: Spinner) {

        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->

            val studentId = userDoc.getString("studentId") ?: return@addOnSuccessListener

            db.collection("materias")
                .whereEqualTo("profesorId", studentId)
                .get()
                .addOnSuccessListener { result ->

                    materias.clear()
                    materiasId.clear()

                    for (doc in result) {

                        val nombre = doc.getString("nombre") ?: "Sin nombre"
                        val id = doc.getString("materiaId") ?: ""

                        materias.add("$nombre ($id)")
                        materiasId.add(id)
                    }

                    val adapter = ArrayAdapter(
                        this,
                        android.R.layout.simple_spinner_item,
                        materias
                    )

                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner.adapter = adapter
                }
        }
    }

    private fun startScanner() {

        val integrator = IntentIntegrator(this)

        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
        integrator.setPrompt("Escanea el QR del alumno")
        integrator.setBeepEnabled(true)
        integrator.initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {

        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)

        if (result != null) {

            if (result.contents != null) {

                processQR(result.contents)

            } else {

                Toast.makeText(this, "Escaneo cancelado", Toast.LENGTH_SHORT).show()
            }

        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun processQR(qrContent: String) {

        val json = JSONObject(qrContent)

        val uid = json.getString("uid")
        val timestamp = json.getLong("timestamp")

        val currentTime = System.currentTimeMillis()

        if (currentTime - timestamp > 120000) {
            Toast.makeText(this, "QR expirado", Toast.LENGTH_SHORT).show()
            return
        }

        mostrarDatosAlumno(uid)
    }

    private fun mostrarDatosAlumno(uid: String) {

        db.collection("users").document(uid).get().addOnSuccessListener { doc ->

            val name = doc.getString("name") ?: "Sin nombre"
            val studentId = doc.getString("studentId") ?: "Sin ID"

            val date = System.currentTimeMillis()
            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            val formattedDate = sdf.format(Date(date))

            val message = """
                
                Alumno: $name
                
                ID: $studentId
                
                Materia: $selectedMateriaId
                
                Fecha: $formattedDate
                
            """.trimIndent()

            AlertDialog.Builder(this)
                .setTitle("Confirmar Asistencia")
                .setMessage(message)
                .setPositiveButton("Confirmar") { _, _ ->

                    saveAttendance(studentId, name, date)
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun saveAttendance(studentId: String, name: String, date: Long) {

        val profesorUid = FirebaseAuth.getInstance().currentUser!!.uid

        val attendance = hashMapOf(

            "studentId" to studentId,
            "name" to name,
            "materiaId" to (selectedMateriaId ?: "sin_materia"),
            "profesorUid" to profesorUid,
            "date" to date
        )

        db.collection("attendance")
            .add(attendance)
            .addOnSuccessListener {

                Toast.makeText(this, "Asistencia registrada", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {

                Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show()
            }
    }
}