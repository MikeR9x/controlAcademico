package com.example.controlacademico.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R

class AlumnoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumno)

        val qrBtn = findViewById<Button>(R.id.qrBtn)
        val viewGradesBtn = findViewById<Button>(R.id.viewGradesBtn)
        val viewMateriasBtn = findViewById<Button>(R.id.viewMateriasBtn)

        qrBtn.setOnClickListener {

            startActivity(
                Intent(this, GenerateQRActivity::class.java)
            )
        }


        viewGradesBtn.setOnClickListener {

            val intent = Intent(this, ViewGradesActivity::class.java)
            startActivity(intent)

        }
        viewMateriasBtn.setOnClickListener {

            val intent = Intent(this, AlumnoMateriasActivity::class.java)
            startActivity(intent)

        }
    }

}
