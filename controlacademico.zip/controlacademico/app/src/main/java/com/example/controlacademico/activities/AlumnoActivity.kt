package com.example.controlacademico.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.example.controlacademico.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AlumnoActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumno)

        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return

        val qrBtn = findViewById<Button>(R.id.qrBtn)
        val viewGradesBtn = findViewById<Button>(R.id.viewGradesBtn)
        val viewMateriasBtn = findViewById<Button>(R.id.viewMateriasBtn)
        val nombreText = findViewById<TextView>(R.id.alumnoNameText)
        val idText = findViewById<TextView>(R.id.alumnoIdText)

        db.collection("users").document(uid).get().addOnSuccessListener { doc ->
            val nombre = doc.getString("name") ?: "Sin nombre"
            val studentId = doc.getString("studentId") ?: "Sin ID"

            nombreText.text = nombre
            idText.text = "ID: $studentId"
        }.addOnFailureListener {
            Toast.makeText(this, "Error al cargar datos del alumno", Toast.LENGTH_SHORT).show()
        }

        qrBtn.setOnClickListener {

            startActivity(
                Intent(this, GenerateQRActivity::class.java)
            )
        }


        viewGradesBtn.setOnClickListener {

            val intent = Intent(this, ViewGradesActivity::class.java)
            startActivity(intent)

        }
        viewMateriasBtn.setOnClickListener {

            val intent = Intent(this, AlumnoMateriasActivity::class.java)
            startActivity(intent)

        }
        val logoutBtn = findViewById<Button>(R.id.logoutBtn)

        logoutBtn.setOnClickListener {
            val sessionManager = SessionManager(this)
            sessionManager.logout()
            FirebaseAuth.getInstance().signOut()  // Cierra sesión también en Firebase
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

}
