package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class EnrollStudentActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    private val materias = mutableListOf<String>()
    private val materiasId = mutableListOf<String>()

    private val alumnos = mutableListOf<String>()
    private val alumnosId = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enroll_student)

        val materiaSpinner = findViewById<Spinner>(R.id.materiaSpinner)
        val alumnoSpinner = findViewById<Spinner>(R.id.alumnoSpinner)
        val enrollBtn = findViewById<Button>(R.id.enrollBtn)

        cargarMaterias(materiaSpinner)
        cargarAlumnos(alumnoSpinner)

        enrollBtn.setOnClickListener {

            val materiaIndex = materiaSpinner.selectedItemPosition
            val alumnoIndex = alumnoSpinner.selectedItemPosition

            val materiaId = materiasId[materiaIndex]
            val alumnoId = alumnosId[alumnoIndex]

            // 1️⃣ Actualizar materia
            db.collection("materias")
                .document(materiaId)
                .update(
                    "alumnos",
                    FieldValue.arrayUnion(alumnoId)
                )
                .addOnSuccessListener {

                    // 2️⃣ Actualizar alumno
                    db.collection("users")
                        .whereEqualTo("studentId", alumnoId)
                        .get()
                        .addOnSuccessListener { result ->

                            for (doc in result) {

                                db.collection("users")
                                    .document(doc.id)
                                    .update(
                                        "materias",
                                        FieldValue.arrayUnion(materiaId)
                                    )
                            }

                            Toast.makeText(this, "Alumno inscrito correctamente", Toast.LENGTH_SHORT).show()
                        }
                }
        }
    }

    private fun cargarMaterias(spinner: Spinner) {

        db.collection("materias")
            .get()
            .addOnSuccessListener { result ->

                materias.clear()
                materiasId.clear()

                for (doc in result) {

                    val nombre = doc.getString("nombre") ?: ""
                    val id = doc.getString("materiaId") ?: ""

                    materias.add("$nombre ($id)")
                    materiasId.add(id)
                }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    materias
                )

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                spinner.adapter = adapter
            }
    }

    private fun cargarAlumnos(spinner: Spinner) {

        db.collection("users")
            .whereEqualTo("role", "alumno")
            .get()
            .addOnSuccessListener { result ->

                alumnos.clear()
                alumnosId.clear()

                for (doc in result) {

                    val nombre = doc.getString("name") ?: ""
                    val id = doc.getString("studentId") ?: ""

                    alumnos.add("$nombre ($id)")
                    alumnosId.add(id)
                }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_item,
                    alumnos
                )

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                spinner.adapter = adapter
            }
    }
}