package com.example.controlacademico.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.example.controlacademico.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth

class AdminActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val createMateriaBtn = findViewById<Button>(R.id.createMateriaBtn)
        val enrollStudentBtn = findViewById<Button>(R.id.enrollStudentBtn)
        val manageUsersBtn = findViewById<Button>(R.id.manageUsersBtn)

        createMateriaBtn.setOnClickListener {

            val intent = Intent(this, CreateMateriaActivity::class.java)
            startActivity(intent)

        }
        enrollStudentBtn.setOnClickListener {

            val intent = Intent(this, EnrollStudentActivity::class.java)
            startActivity(intent)

        }

        manageUsersBtn.setOnClickListener {
            startActivity(Intent(this, ManageUsersActivity::class.java))
        }
        val logoutBtn = findViewById<Button>(R.id.logoutBtn)

        logoutBtn.setOnClickListener {
            val sessionManager = SessionManager(this)
            sessionManager.logout()
            FirebaseAuth.getInstance().signOut()  // Cierra sesión también en Firebase
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}