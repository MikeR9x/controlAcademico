package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ViewGradesActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_grades)

        val gradesText = findViewById<TextView>(R.id.gradesText)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->

            // Obtener materias inscritas
            val materiasArray = userDoc.get("materias") as? List<String>
            if (materiasArray.isNullOrEmpty()) {
                gradesText.text = "No tienes calificaciones registradas."
                return@addOnSuccessListener
            }

            // Obtener calificaciones guardadas en el campo 'grades'
            val gradesMap = userDoc.get("grades") as? Map<String, Map<String, Any>>

            val textBuilder = StringBuilder()

            for (materiaId in materiasArray) {

                db.collection("materias").document(materiaId).get().addOnSuccessListener { matDoc ->

                    val nombre = matDoc.getString("nombre") ?: "Sin nombre"
                    val profesor = matDoc.getString("profesorNombre") ?: "Sin profesor"
                    val horario = matDoc.getString("horario") ?: "Sin horario"

                    val calificaciones = gradesMap?.get(materiaId)
                    val p1 = calificaciones?.get("parcial1") ?: "-"
                    val p2 = calificaciones?.get("parcial2") ?: "-"
                    val finalGrade = calificaciones?.get("final") ?: "-"

                    textBuilder.append("Materia: $nombre ($materiaId)\n")
                    textBuilder.append("Profesor: $profesor\n")
                    textBuilder.append("Horario: $horario\n")
                    textBuilder.append("Calificaciones:\n")
                    textBuilder.append("  Parcial 1: $p1\n")
                    textBuilder.append("  Parcial 2: $p2\n")
                    textBuilder.append("  Final: $finalGrade\n")
                    textBuilder.append("-----------------------------\n")

                    gradesText.text = textBuilder.toString()
                }
            }

        }.addOnFailureListener {
            Toast.makeText(this, "Error al cargar calificaciones", Toast.LENGTH_SHORT).show()
        }
    }
}