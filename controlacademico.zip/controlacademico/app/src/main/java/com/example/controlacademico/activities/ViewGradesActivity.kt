package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ViewGradesActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_grades)

        val gradesText = findViewById<TextView>(R.id.gradesText)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->
            val materiasMap = userDoc.get("materias") as? Map<String, Map<String, Any>>
            if (materiasMap.isNullOrEmpty()) {
                gradesText.text = "No tienes calificaciones registradas."
                return@addOnSuccessListener
            }

            val textBuilder = StringBuilder()

            for ((materiaId, info) in materiasMap) {

                db.collection("materias").document(materiaId).get().addOnSuccessListener { matDoc ->

                    val nombre = matDoc.getString("nombre") ?: "Sin nombre"
                    val profesor = matDoc.getString("profesorNombre") ?: "Sin profesor"
                    val horario = matDoc.getString("horario") ?: "Sin horario"

                    val calificaciones = info["calificaciones"] as? Map<String, Any>
                    val p1 = calificaciones?.get("parcial1") ?: "-"
                    val p2 = calificaciones?.get("parcial2") ?: "-"
                    val finalGrade = calificaciones?.get("final") ?: "-"

                    textBuilder.append("Materia: $nombre ($materiaId)\n")
                    textBuilder.append("Profesor: $profesor\n")
                    textBuilder.append("Horario: $horario\n")
                    textBuilder.append("Calificaciones:\n")
                    textBuilder.append("  Parcial 1: $p1\n")
                    textBuilder.append("  Parcial 2: $p2\n")
                    textBuilder.append("  Final: $finalGrade\n")
                    textBuilder.append("-----------------------------\n")

                    gradesText.text = textBuilder.toString()
                }
            }

        }.addOnFailureListener {
            Toast.makeText(this, "Error al cargar calificaciones", Toast.LENGTH_SHORT).show()
        }
    }
}