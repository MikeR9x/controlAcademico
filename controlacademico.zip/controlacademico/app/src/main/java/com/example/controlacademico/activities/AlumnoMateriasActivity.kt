package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AlumnoMateriasActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumno_materias)

        val text = findViewById<TextView>(R.id.materiasAlumnoText)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->

            val materiasList = userDoc.get("materias") as? List<String>

            if (materiasList.isNullOrEmpty()) {
                text.text = "No estás inscrito en ninguna materia."
                return@addOnSuccessListener
            }

            val calendario = mutableMapOf(
                "Lunes" to mutableListOf<String>(),
                "Martes" to mutableListOf<String>(),
                "Miércoles" to mutableListOf<String>(),
                "Jueves" to mutableListOf<String>(),
                "Viernes" to mutableListOf<String>()
            )

            var procesadas = 0
            val totalMaterias = materiasList.size

            for (materiaId in materiasList) {

                db.collection("materias").document(materiaId).get().addOnSuccessListener { matDoc ->

                    val nombre = matDoc.getString("nombre") ?: "Sin nombre"
                    val horario = matDoc.getString("horario") ?: "Sin horario"
                    val profesor = matDoc.getString("profesorNombre") ?: "Sin profesor"
                    val dias = matDoc.getString("dias") ?: ""

                    val textoMateria = """
                        📘 $nombre
                        ID: $materiaId
                        👨‍🏫 $profesor
                        ⏰ $horario
                    """.trimIndent()

                    val listaDias = dias.split(" y ")

                    for (dia in listaDias) {
                        val limpio = dia.trim()
                        if (calendario.containsKey(limpio)) {
                            calendario[limpio]?.add(textoMateria)
                        }
                    }

                    procesadas++

                    if (procesadas == totalMaterias) {

                        val builder = StringBuilder()

                        for ((dia, lista) in calendario) {

                            builder.append("📅 $dia\n")

                            if (lista.isEmpty()) {
                                builder.append("  (Sin materias)\n")
                            } else {
                                for (materia in lista) {
                                    builder.append("  $materia\n\n")
                                }
                            }

                            builder.append("\n")
                        }

                        text.text = builder.toString()
                    }
                }
            }

        }.addOnFailureListener {
            Toast.makeText(this, "Error al cargar materias", Toast.LENGTH_SHORT).show()
        }
    }
}