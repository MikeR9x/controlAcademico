package com.example.controlacademico.activities

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlacademico.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AlumnoMateriasActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumno_materias)

        val text = findViewById<TextView>(R.id.materiasAlumnoText)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid

        db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->
            val materiasMap = userDoc.get("materias") as? Map<String, Map<String, Any>>
            if (materiasMap.isNullOrEmpty()) {
                text.text = "No estás inscrito en ninguna materia."
                return@addOnSuccessListener
            }

            val materiasText = StringBuilder()

            for ((materiaId, info) in materiasMap) {

                db.collection("materias").document(materiaId).get().addOnSuccessListener { matDoc ->

                    val nombre = matDoc.getString("nombre") ?: "Sin nombre"
                    val profesor = matDoc.getString("profesorNombre") ?: "Sin profesor"
                    val horario = matDoc.getString("horario") ?: "Sin horario"


                    materiasText.append("Materia: $nombre ($materiaId)\n")
                    materiasText.append("Profesor: $profesor\n")
                    materiasText.append("Horario: $horario\n")
                    materiasText.append("-----------------------------\n")

                    text.text = materiasText.toString()
                }
            }

        }.addOnFailureListener {
            Toast.makeText(this, "Error al cargar materias", Toast.LENGTH_SHORT).show()
        }
    }
}